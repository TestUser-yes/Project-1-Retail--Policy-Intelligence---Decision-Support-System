"""Database dependency helpers."""
